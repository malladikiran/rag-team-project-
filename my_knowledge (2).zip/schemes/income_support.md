---
type: Scheme
title: Farmer Income Support
---
# Farmer Income Support
## Who can apply
Small and marginal farmers who own farmland can apply for yearly income support from the government.
## Documents
Keep your land record, bank passbook and ID proof ready.