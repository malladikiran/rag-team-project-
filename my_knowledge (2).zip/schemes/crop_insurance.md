---
type: Scheme
title: Crop Insurance
---
# Crop Insurance
## What it covers
Insurance helps farmers when crops are damaged by flood, drought, hail, cyclone or pests.
## How to claim
Inform the insurance company or the agriculture office within the time limit and keep photos of the damaged field.