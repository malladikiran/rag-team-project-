---
type: Scheme
title: Farm Loan Card
---
# Farm Loan Card
## Purpose
A credit card for farmers to get low interest loans for seeds, fertilizer and farm needs.
## Documents
Land record, ID proof and bank account details are needed.