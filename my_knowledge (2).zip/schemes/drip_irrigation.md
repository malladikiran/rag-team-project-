---
type: Scheme
title: Drip Irrigation Subsidy
---
# Drip Irrigation Subsidy
## Benefit
Farmers can get financial support to install drip or sprinkler systems that save water.
## Where to apply
Apply at the local agriculture or horticulture office.