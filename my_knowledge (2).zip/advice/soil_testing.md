---
type: Advice
title: Soil Testing
---
# Soil Testing
## Why test
A soil test tells you which nutrients are low, so you use only the fertilizer you need.
## When
Test the soil before the sowing season.