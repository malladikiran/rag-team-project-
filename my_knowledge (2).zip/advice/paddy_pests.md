---
type: Advice
title: Paddy Pest Care
status: draft
---
# Paddy Pest Care
## Signs
Yellow leaves, holes in leaves or dried tips can show a pest attack.
## What to do
Show the plant to the local agriculture officer before spraying any chemical.